package com.example.android.aboutme

import android.content.Context
import android.inputmethodservice.InputMethodService
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.core.content.getSystemService
import androidx.databinding.DataBindingUtil
import com.example.android.aboutme.databinding.ActivityMainBinding
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val myName: MyName = MyName("Thientv")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_main)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        /*btn_done.setOnClickListener{
            addNickname(btn_done)
        }*/

        binding.myName = myName

        binding.btnDone.setOnClickListener {
            addNickname(binding.btnDone)
        }
    }


    private fun addNickname(view: View){

        binding.apply {
            myName?.nickName = nickname_add.text.toString()
            invalidateAll()
            nickname_add.visibility = View.GONE
            view.visibility = View.GONE
            nickname_text.visibility = View.VISIBLE
        }




        // hide keyboar
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(view.windowToken, 0)

    }
}
